# create settings 
START_CHAR = "S"
END_CHAR = "E"
PATH_CHAR = "1"
WALL_CHAR = "0"

NAMES_ITEMS = ["a needle",
               "a platic tube",
               "an ether"]
               