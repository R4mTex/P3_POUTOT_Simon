# create a class that will generate MacGyver


class MacGyver:

    # generate MacGyver logic
    def __init__(self, map):
        self.map = map
